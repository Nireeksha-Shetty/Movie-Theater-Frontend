import React from 'react'

export const PageNotFound = () => {
  return (
    <div>PageNotFound</div>
  )
}
