//  import './App.css';

function Cast() {
    return (
      
        <div className="Cast">
         <p id="castname">Cast*</p>
        <input type="text" id="myTexts"></input>
      </div>
    );
  }
  
  export default Cast;