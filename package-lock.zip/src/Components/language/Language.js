//  import './App.css';

function Language() {
    return (
      
        <div className="Language">
         <p id="Language">Language*</p>
        <input type="text" id="myLanguage"></input>
      </div>
    );
  }
  
  export default Language ;