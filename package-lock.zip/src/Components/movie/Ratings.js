//  import './App.css';

function Ratings() {
    return (
      
        <div className="Ratings">
         <p id="Ratings">Ratings*</p>
        <input type="text" id="myRatings"></input>
      </div>
    );
  }
  
  export default Ratings ;