//  import './App.css';

function MovieName() {
  return (
    
      <div className="Moviename">
       <p id="name">Movie Name*</p>
      <input type="text" id="myText"></input>
    </div>
  );
}

export default MovieName;