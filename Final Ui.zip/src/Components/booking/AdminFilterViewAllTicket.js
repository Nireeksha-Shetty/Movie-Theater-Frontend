import React from "react";
import AdminFilter from "./AdminFilter";

function AdminFilterViewAllTicket() {
  return (
    <div className="admin_filter_view_all_ticket">
      <AdminFilter />
    </div>
  );
}

export default AdminFilterViewAllTicket;
