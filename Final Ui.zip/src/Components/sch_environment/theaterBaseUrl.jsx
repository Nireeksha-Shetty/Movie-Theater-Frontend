const theaterBase = "https://theater.learn.skillassure.com/theater/theater/"
export default theaterBase;